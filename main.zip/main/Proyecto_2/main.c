//********************************************************************************
//Universidad del Valle de Guatemala
//IE2023: Programacion de Microcontroladores
//Autor: Fernando Gabriel Caballeros Cu
//Proyecto: Proyecto_2.c
//Archivo: main.c
//Hardware: ATMega328p
// Created: 30/04/2024 14:39:55
//********************************************************************************
#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include "PWM1/PWM1.h"
#include "PWM2/PWM2.h"
#include "ADC/ADC.h"
volatile uint8_t valorADC=0;
volatile uint8_t PuertoADC=3;
volatile uint16_t destino=0;

void init_pins(void);
void init_UART9600(void);
void writeText_UART(char* texto);

volatile uint8_t counter = 0;  // Contador inicial
volatile uint8_t boton_estado = 0;
volatile uint8_t boton_po_1 = 0;
uint8_t read_button_c();
uint8_t read_button(uint8_t button_pin);
void handle_counter();
void increment_counter();
void debounce();
void EEPROM_write(unsigned int uiAddress, unsigned char ucData);
unsigned char EEPROM_read(unsigned int uiAddress);
#define MAX_COUNT 3
#define BUTTON1_PIN PD7


volatile char ventana;
volatile char menu = 0;

volatile char anterior = '\0';
volatile char buffer[10];
volatile uint8_t buffer_index = 0;
volatile uint8_t data_received = 0;


uint8_t valor_1 = 0;
uint8_t valor_2 = 0;
uint8_t valor_3 = 0;
uint8_t valor_4 = 0;


uint16_t reescalar(uint8_t valor, uint8_t max_origen, uint16_t max_destino) {
	// Convertir el valor al rango 0 - max_origen
	float valor_normalizado = (float)valor / max_origen;

	// Escalar el valor al rango 0 - max_destino
	uint16_t valor_reescalado = valor_normalizado * max_destino;

	return valor_reescalado;
}


int main(void)
{
	init_pins();
	init_UART9600();
	init_ADC(0, 0, 128);
	sei();
	
	//
	init_ADC(0,0,128);
	
	destino=315;
	int preescaler=1024;
	
	init_PWM1A(0,6,preescaler,destino);
	init_PWM1B(0);
	init_PWM2A(0, 3, preescaler);
	init_PWM2B(0);
	
	/*writeText_UART("\nPresione la opcion correspondiente\n");
	writeText_UART("1. Modo Manual\n");
	writeText_UART("2. Modo EEPROM\n");
	writeText_UART("3. Modo UART\n");*/
    while (1) 
    {
		
		debounce();
		if (boton_estado) {
			increment_counter();
			boton_estado = 0;
		}
		handle_counter();
		if (menu == 1){
			if (PuertoADC==3){
				valor_1 = readADC(3);
				uint16_t valor_reescalado = reescalar(valor_1, 255, 37);
				duty_cycle1A(valor_reescalado);
				PuertoADC++;
			}else if (PuertoADC==4){
				valor_2 =readADC(4);
				uint16_t valor_reescalado = reescalar(valor_2, 255, 37);
				duty_cycle1B(valor_reescalado);
				PuertoADC++;
			}else if (PuertoADC==5){
				valor_3 =readADC(5);
				uint16_t valor_reescalado = reescalar(valor_3, 255, 37);
				duty_cycle2A(valor_reescalado);
				PuertoADC++;
			}else if (PuertoADC==6){
				valor_4 =readADC(6);
				uint16_t valor_reescalado = reescalar(valor_4, 255, 37);
				duty_cycle2B(valor_reescalado);
				PuertoADC=3;
			}else{
				PuertoADC=3;
			} 
			if (!(PIND & (1 << 7))) {
				EEPROM_write(0, valor_1);
				EEPROM_write(1, valor_2);
				EEPROM_write(2, valor_3);
				EEPROM_write(3, valor_4);
			}else if(!(PIND & (1 << 6))) {
				EEPROM_write(4, valor_1);
				EEPROM_write(5, valor_2);
				EEPROM_write(6, valor_3);
				EEPROM_write(7, valor_4);
			}else if(!(PIND & (1 << 5))){
				EEPROM_write(8, valor_1);
				EEPROM_write(9, valor_2);
				EEPROM_write(0xA, valor_3);
				EEPROM_write(0xB, valor_4);
			}else if(!(PIND & (1 << 4))){
				EEPROM_write(0xC, valor_1);
				EEPROM_write(0xD, valor_2);
				EEPROM_write(0xE, valor_3);
				EEPROM_write(0xF, valor_4);
			}
		}
		if (menu == 2){
			if (!(PIND & (1 << 7))) {
				valor_1 = EEPROM_read(0);
				valor_2 = EEPROM_read(1);
				valor_3 = EEPROM_read(2);
				valor_4 = EEPROM_read(3);
				uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
				uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
				uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
				uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
				duty_cycle1A(valor_reescalado_1);
				duty_cycle2A(valor_reescalado_2);
				duty_cycle1B(valor_reescalado_3);
				duty_cycle2B(valor_reescalado_4);
			}else if(!(PIND & (1 << 6))) {
				valor_1 = EEPROM_read(4);
				valor_2 = EEPROM_read(5);
				valor_3 = EEPROM_read(6);
				valor_4 = EEPROM_read(7);
				uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
				uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
				uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
				uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
				duty_cycle1A(valor_reescalado_1);
				duty_cycle2A(valor_reescalado_2);
				duty_cycle1B(valor_reescalado_3);
				duty_cycle2B(valor_reescalado_4);
			}else if(!(PIND & (1 << 5))){
				valor_1 = EEPROM_read(8);
				valor_2 = EEPROM_read(9);
				valor_3 = EEPROM_read(0xA);
				valor_4 = EEPROM_read(0xB);
				uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
				uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
				uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
				uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
				duty_cycle1A(valor_reescalado_1);
				duty_cycle2A(valor_reescalado_2);
				duty_cycle1B(valor_reescalado_3);
				duty_cycle2B(valor_reescalado_4);
			}else if(!(PIND & (1 << 4))){
				valor_1 = EEPROM_read(0xC);
				valor_2 = EEPROM_read(0xD);
				valor_3 = EEPROM_read(0xE);
				valor_4 = EEPROM_read(0xF);
				uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
				uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
				uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
				uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
				duty_cycle1A(valor_reescalado_1);
				duty_cycle2A(valor_reescalado_2);
				duty_cycle1B(valor_reescalado_3);
				duty_cycle2B(valor_reescalado_4);
			}
		}
    }
}

void init_pins(void){
	DDRC &= ~(1 << DDC0) & ~(1 << DDC3) & ~(1 << DDC4) & ~(1 << DDC5) & ~(1 << DDC6);
	PORTC |= (1 << PORTC0) | (1 << PORTC3)| (1 << PORTC4)| (1 << PORTC5)| (1 << PORTC6);
	DDRD &= ~(1 << DDD7) & ~(1 << DDD6) & ~(1 << DDD5) & ~(1 << DDD4);
	PORTD |= (1 << PORTD7) | (1 << PORTD6)| (1 << PORTD5)| (1 << PORTD4);
	
	PORTB |= (1 << PORTB5) | (1 << PORTB4) | (1 << PORTB0);
}

void init_UART9600(void){
	//Paso 1: configurar TX y RX
	DDRD &= ~(1 << DDD0);
	DDRD |= (1 << DDD1);
	//Paso 2: configurar registro A, modo Fast U2x0 = 1
	UCSR0A = 0;
	UCSR0A |= (1 << U2X0);
	//Paso 3: Configurar resgistro B, HABILITAR ISR RX, HABILITAMOS RX Y TX
	UCSR0B = 0;
	UCSR0B |= (1 << RXCIE0) | (1 << RXEN0) | (1 << TXEN0);
	//PASO 4: CONFIGURAR C > FRAME: 8 BITS DE DATOS, NO PARIDAD, 1 BIR DE STOP
	UCSR0C = 0;
	UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00);
	//PASO 5: BAUDRATE = 9600
	UBRR0 = 207;
}

void writeText_UART(char* texto){
	uint8_t i;
	for(i = 0; texto[i]!= '\0';i++){
		while(!(UCSR0A & (1 << UDRE0)));
		UDR0 = texto[i];
	}
}

//******************************************************************
void increment_counter() {
	// Incrementar el contador y resetear si excede el valor m�ximo
	counter = (counter % MAX_COUNT) + 1;
}

void handle_counter() {
	// Realizar acciones basadas en el valor del contador
	
	switch (counter) {
		case 1:
			// Acci�n para el contador = 1
			PORTB |= (1 << PORTB5);
			PORTB &= ~(1 << PORTB4);
			PORTB &= ~(1 << PORTB0);
			writeText_UART("Modo Manual\n");
			menu = 1;
			break;
		case 2:
			// Acci�n para el contador = 2
			PORTB &= ~(1 << PORTB5);
			PORTB |= (1 << PORTB4);
			PORTB &= ~(1 << PORTB0);
			writeText_UART("Modo EEPROM\n");
			menu = 2;
			break;
		case 3:
			// Acci�n para el contador = 3
			PORTB &= ~(1 << PORTB5);
			PORTB &= ~(1 << PORTB4);
			PORTB |= (1 << PORTB0);
			writeText_UART("Modo UART\n");
			menu = 3;
			break;
	}
}
uint8_t read_button_c() {
	return PINC & (1 << PORTC0);
}

uint8_t read_button(uint8_t button_pin) {
	return PIND & (1 << button_pin); 
}

void debounce() {
	static uint8_t count = 0;
	static uint8_t last_button_state = 1;
	uint8_t current_button_state = read_button_c();
	
	if (current_button_state == last_button_state) {
		if (count < 1) {
			count++;
		}else if (count == 1 && last_button_state == 0) {
			boton_estado = 1;
		}
		} else {
		count = 0;
	}
	
	last_button_state = current_button_state;
	_delay_ms(60);  // Ajusta el retardo seg�n sea necesario
}

void EEPROM_write(unsigned int uiAddress, unsigned char ucData){
	while(EECR & (1 << EEPE))
	;
	
	EEAR = uiAddress;
	EEDR = ucData;
	
	EECR |= (1 << EEMPE);
	
	EECR |= (1 << EEPE);
}

unsigned char EEPROM_read(unsigned int uiAddress){
	while(EECR & (1 << EEPE))
	;
	
	EEAR = uiAddress;
	
	EECR |= (1 << EERE);
	
	return EEDR;
}

ISR(USART_RX_vect){
	ventana = UDR0;
	if (anterior == '6' || anterior == '7' || anterior == '8' || anterior == '9'){
		if (menu == 3) {
			if (ventana == 'F') {
				buffer[buffer_index] = '\0';  // Terminar la cadena
				data_received = 1;
				buffer_index = 0;
				}else if (buffer_index < 9) {
					buffer[buffer_index++] = ventana;
				}
			}else {
				anterior = ventana;
			}
		}else{
			if (ventana == '1') {
				increment_counter();
				handle_counter();
			}else if (ventana == '2'){
				if(menu == 1){
					EEPROM_write(0, valor_1);
					EEPROM_write(1, valor_2);
					EEPROM_write(2, valor_3);
					EEPROM_write(3, valor_4);
				}else if (menu == 2){
					valor_1 = EEPROM_read(0);
					valor_2 = EEPROM_read(1);
					valor_3 = EEPROM_read(2);
					valor_4 = EEPROM_read(3);
					uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
					uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
					uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
					uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
					duty_cycle1A(valor_reescalado_1);
					duty_cycle2A(valor_reescalado_2);
					duty_cycle1B(valor_reescalado_3);
					duty_cycle2B(valor_reescalado_4);
				}
			}else if(ventana == '3'){
				if(menu == 1){
					EEPROM_write(4, valor_1);
					EEPROM_write(5, valor_2);
					EEPROM_write(6, valor_3);
					EEPROM_write(7, valor_4);
				}else if(menu ==2){
					valor_1 = EEPROM_read(4);
					valor_2 = EEPROM_read(5);
					valor_3 = EEPROM_read(6);
					valor_4 = EEPROM_read(7);
					uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
					uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
					uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
					uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
					duty_cycle1A(valor_reescalado_1);
					duty_cycle2A(valor_reescalado_2);
					duty_cycle1B(valor_reescalado_3);
					duty_cycle2B(valor_reescalado_4);
				}
			}else if(ventana == '4'){
				if(menu == 1){
					EEPROM_write(8, valor_1);
					EEPROM_write(9, valor_2);
					EEPROM_write(0xA, valor_3);
					EEPROM_write(0xB, valor_4);
				}else if(menu ==2){
					valor_1 = EEPROM_read(8);
					valor_2 = EEPROM_read(9);
					valor_3 = EEPROM_read(0xA);
					valor_4 = EEPROM_read(0xB);
					uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
					uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
					uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
					uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
					duty_cycle1A(valor_reescalado_1);
					duty_cycle2A(valor_reescalado_2);
					duty_cycle1B(valor_reescalado_3);
					duty_cycle2B(valor_reescalado_4);
				}				
			}else if(ventana == '5'){
				if(menu == 1){
					EEPROM_write(0xC, valor_1);
					EEPROM_write(0xD, valor_2);
					EEPROM_write(0xE, valor_3);
					EEPROM_write(0xF, valor_4);
				}else if(menu ==2){
					valor_1 = EEPROM_read(0xC);
					valor_2 = EEPROM_read(0xD);
					valor_3 = EEPROM_read(0xE);
					valor_4 = EEPROM_read(0xF);
					uint16_t valor_reescalado_1 = reescalar(valor_1, 255, 37);
					uint16_t valor_reescalado_2 = reescalar(valor_2, 255, 37);
					uint16_t valor_reescalado_3 = reescalar(valor_3, 255, 37);
					uint16_t valor_reescalado_4 = reescalar(valor_4, 255, 37);
					duty_cycle1A(valor_reescalado_1);
					duty_cycle2A(valor_reescalado_2);
					duty_cycle1B(valor_reescalado_3);
					duty_cycle2B(valor_reescalado_4);
				}				
			}
			anterior = ventana;
		}
		
		if (data_received == 1) {
			if (anterior == '6') {
				duty_cycle2A(atoi(buffer));
				} else if (anterior == '7') {
				duty_cycle1B(atoi(buffer));
				} else if (anterior == '8') {
				duty_cycle1A(atoi(buffer));
				} else if (anterior == '9') {
				duty_cycle2B(atoi(buffer));
			}
			data_received = 0;
			anterior = ventana;
		}
}
		/*
		if (estado == 3) {
			if (opcion == '4') {
				secuencia1();
				} else if (opcion == '5'){
				secuencia2();
			}
		}
		anterior = opcion;
	}
	
	if (estado == 1 || estado == 2){
		if (opcion == '2') {
			if (eprom_pos == 4){
				eprom_pos = 1;
				} else {
				eprom_pos++;
			}
			leds();
		}
		
		if (opcion == '3') {
			if (estado == 1){
				save_pose(eprom_pos-1);
				} else {
				load_pose(eprom_pos-1);
			}
		}
	}
	
	
	if (data_received == 1) {
		if (anterior == '6') {
			duty_cycle2A(atoi(buffer));
			} else if (anterior == '7') {
			duty_cycle1B(atoi(buffer));
			} else if (anterior == '8') {
			duty_cycle1A(atoi(buffer));
			} else if (anterior == '9') {
			duty_cycle2B(atoi(buffer));
		}
		data_received = 0;
		anterior�=�opcion;
	}
}*/